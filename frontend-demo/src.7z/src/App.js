import React from "react";
import "./App.css";
import NavBar from "./components/NavBar";
import ClassRoom from './components/ClassRoom'
function App() {
  return (
    <div>
      <ClassRoom />
    </div>
  );
}

export default App;
