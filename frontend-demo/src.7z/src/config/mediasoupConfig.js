export const validateEvents = true;

export const socketClient = {
  path: "ws://9d451d68.ngrok.io"
};
