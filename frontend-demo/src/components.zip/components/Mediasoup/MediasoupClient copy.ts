import MediasoupSdk from "./lib/MediasoupSdk";

class MediasoupClient extends MediasoupSdk {
  

  joinConference = (name) => {
    return new Promise(async (resolve, reject) => {
      try {
        console.log("MediasoupServer", "joinConference", `${name}`);
        await super.signaling.getRouterCapabilities(
          (track: MediaStreamTrack) => {
            resolve(track);
          }
        );
      } catch (error) {
        console.error("MediasoupServer", "joinConference", `${name}`, error);
        reject(error);
      }
    });
  };

  broadcast = () => {
    return new Promise(async (resolve, reject) => {
      try {
        console.log("MediasoupServer", "broadcast");
        await super.signaling.producerBroadcast((status: boolean) => {
          resolve(status);
        });
      } catch (error) {
        console.error("MediasoupServer", "broadcast", error);
        reject(error);
      }
    });
  };
}

export default MediasoupServer;
